World Cup 2026 Sweep Website - Automatic Version

How to deploy:
1. Unzip this folder.
2. Drag the folder into Vercel, or upload it to GitHub and import it into Vercel.
3. In Vercel, go to Project Settings > Environment Variables.
4. Add API_FOOTBALL_KEY with your API-Football key.
5. Redeploy.

The site refreshes live scores every 5 minutes using /api/results.js.
Manual scores are still available as a fallback and are saved locally in the browser.
